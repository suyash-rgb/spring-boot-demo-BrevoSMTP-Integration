package com.example.spring_boot_demo_brevo_integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemoBrevoIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}

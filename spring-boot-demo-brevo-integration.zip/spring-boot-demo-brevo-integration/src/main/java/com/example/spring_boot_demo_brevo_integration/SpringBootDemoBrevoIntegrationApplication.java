package com.example.spring_boot_demo_brevo_integration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemoBrevoIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoBrevoIntegrationApplication.class, args);
	}

}
